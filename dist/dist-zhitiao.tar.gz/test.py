import asyncio

import sys

from models import User
from orm import select, create_pool, execute


async def test(loop):
    await create_pool(loop=loop, host='127.0.0.1', user='root', password='1234', db='awesome')
    u = User(name='Test', email='88888888@qq.com', passwd='000', image='www.www.www')
    await u.save()


loop = asyncio.get_event_loop()
loop.run_until_complete(test(loop))
loop.close()
if loop.is_closed():
    sys.exit(0)
