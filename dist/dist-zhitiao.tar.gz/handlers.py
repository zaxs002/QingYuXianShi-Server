from coroweb import get
from models import User


@get('/api/users')
async def index():
    users = await User.findAll()
    return {
        'status': 200,
        'users': users,
        '经度': '12.3333',
        '纬度': '79.9999'
    }


@get('/api/users/{name}')
async def getUser(name):
    user = await User.find(name=name)
    return {
        'status': 200,
        'user': user
    }
